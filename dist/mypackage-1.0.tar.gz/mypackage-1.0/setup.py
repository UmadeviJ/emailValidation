from setuptools import setup

setup(
    name='mypackage',
    version='1.0',
    packages=['biogen'],
    url='',
    license='',
    author='uma',
    author_email='uma.omnn@gmail.com',
    description='To Verify email'
)
