from biogen import emailValidation
email=input("Enter the input \n")
emailValidation.check(email)